import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-component',
  templateUrl: './travel-component.component.html',
  styleUrls: ['./travel-component.component.css']
})
export class TravelComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  travelRegister(travelRegisterForm){
    
  }
}
