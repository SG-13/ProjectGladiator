import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-component',
  templateUrl: './vehicle-component.component.html',
  styleUrls: ['./vehicle-component.component.css']
})
export class VehicleComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  vehicleRegister(form){
    
  }

}
