import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-insurance-component',
  templateUrl: './choose-insurance-component.component.html',
  styleUrls: ['./choose-insurance-component.component.css']
})
export class ChooseInsuranceComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
